To compile:
  javac src/NumberGuessingGame.java

To run:
  java -cp src NumberGuessingGame
