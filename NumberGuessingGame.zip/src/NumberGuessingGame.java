import java.util.Random;
import java.util.Scanner;

public class NumberGuessingGame {

    public static int playRound(Scanner scanner) {
        Random random = new Random();
        int numberToGuess = random.nextInt(100) + 1; // 1 to 100
        int attemptsAllowed = 7;
        int attempts = 0;

        System.out.println("🎯 I'm thinking of a number between 1 and 100.");
        System.out.println("💡 You have " + attemptsAllowed + " attempts to guess it.");

        while (attempts < attemptsAllowed) {
            System.out.print("🔢 Enter your guess: ");
            int guess;
            try {
                guess = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("❌ Invalid input! Please enter a valid number.");
                continue;
            }

            attempts++;

            if (guess == numberToGuess) {
                System.out.println("✅ Congratulations! You guessed it in " + attempts + " attempt(s).");
                return attempts;
            } else if (guess < numberToGuess) {
                System.out.println("📉 Too low!");
            } else {
                System.out.println("📈 Too high!");
            }
        }

        System.out.println("❌ You've used all your attempts. The number was: " + numberToGuess);
        return -1; // Indicates loss
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int totalScore = 0;
        int roundsPlayed = 0;

        System.out.println("🎮 Welcome to the Number Guessing Game!");

        boolean playAgain = true;
        while (playAgain) {
            System.out.println("\n▶️ Starting Round " + (roundsPlayed + 1));
            int result = playRound(scanner);
            roundsPlayed++;

            if (result != -1) {
                int roundScore = Math.max(0, 10 - result); // Lower attempts = higher score
                totalScore += roundScore;
                System.out.println("🏆 You earned " + roundScore + " points this round.");
            } else {
                System.out.println("😢 No points this round.");
            }

            System.out.print("🔁 Do you want to play another round? (yes/no): ");
            String answer = scanner.nextLine().toLowerCase();
            if (!answer.equals("yes")) {
                playAgain = false;
            }
        }

        System.out.println("\n📊 Game Over!");
        System.out.println("You played " + roundsPlayed + " round(s).");
        System.out.println("🎯 Your total score: " + totalScore + " points.");
        System.out.println("👋 Thanks for playing!");

        scanner.close();
    }
}
